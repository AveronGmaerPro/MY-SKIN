package com.example.myskin;

import net.fabricmc.api.ModInitializer;

public class MySkinMod implements ModInitializer {
    @Override
    public void onInitialize() {
        System.out.println("My Skin Mod Loaded!");
    }
}is logger is used to write text to the console and the log file.
	// It is considered best practice to use your mod id as the logger's name.
	// That way, it's clear which mod wrote info, warnings, and errors.
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// This code runs as soon as Minecraft is in a mod-load-ready state.
		// However, some things (like resources) may still be uninitialized.
		// Proceed with mild caution.

		LOGGER.info("Hello Fabric world!");
	}
}